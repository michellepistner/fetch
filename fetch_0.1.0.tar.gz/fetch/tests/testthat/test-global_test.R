test_that("globalFetch", {
  set.seed(1)
  Y = rmultinom(10, 10000, prob = seq(1:15))
  X = matrix(sample(1:2,10,replace=TRUE),ncol = 10)
  out = fetch(Y, X, denom = "iqlr", test = "global")

  expect_equal(round(c(out$f_stat),1), c(165743.8))
})


test_that("localFetch", {
  set.seed(1)
  Y = rmultinom(10, 10000, prob = seq(1:15))
  X = matrix(sample(1:2,10,replace=TRUE),ncol = 10)
  out =fetch(Y, X, denom = "iqlr", test = "t")

  expect_equal(out[1,1], 0.61035341)
})

test_that("localFetchvsAldex", {
  set.seed(1)
  Y = rmultinom(10, 10000, prob = seq(1:15))
  X = matrix(sample(1:2,10,replace=TRUE),ncol = 10)
  out =fetch(Y, X, denom = "all", test = "t")

  out2 = ALDEx2::aldex(Y,c(X))
  sig2 = ifelse(out2[,11] > 0.05,0,1)
  sig = ifelse(out[,4] > 0.05,0,1)

  expect_equal(sig, sig2)
})
