test_that("compareWithAldex", {
  set.seed(1)
  Y = rmultinom(10, 10000, prob = seq(1:15))
  X = matrix(sample(1:2,10,replace=TRUE),ncol = 10)

  out =fetch(Y, X, denom = "all", test = "t")

  out.aldex = ALDEx2::aldex(Y, c(X), mc.samples = 2000, effect = FALSE)
  expect_equal(round(out[1:10,1],1), round(out.aldex[1:10,1],1))
})
