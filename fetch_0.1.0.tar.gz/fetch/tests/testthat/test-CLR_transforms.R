test_that("CLR transform", {
  Y = rmultinom(10, 10000, prob = seq(1:15))
  clr_samps = multDirichlet(Y, X = sample(1:2,10,replace=TRUE))
  lambda_list_tmp = list()
  for(i in 1:dim(clr_samps$lambda_mat)[2]){
    lambda_list_tmp[[i]] = clr_samps$lambda_mat[,i,]
    dimnames(lambda_list_tmp[[i]]) = dimnames(clr_samps$lambda_list[[i]])
  }
  names(lambda_list_tmp) = names(clr_samps$lambda_list)
  expect_equal(lambda_list_tmp, clr_samps$lambda_list)
})
