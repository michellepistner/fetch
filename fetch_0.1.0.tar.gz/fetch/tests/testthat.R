library(testthat)
library(fetch)

test_check("fetch")
