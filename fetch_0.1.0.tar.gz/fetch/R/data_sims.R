#' Draws Multinomial Dirichlet Centered Logratio (CLR) samples
#'
#' @param Y A matrix of counts.
#' @param X A matrix of covariates.
#' @param n_samples The number of samples to be drawn.
#' @param denom What samples should be included to calculated the denominator of the CLR?
#'
#' @return A list containing \code{lambda_list} (a list in \code{ALDEx2} format) and \code{lambda_mat} (a matrix matching \code{fido} format).
#'
#'
#' @export
multDirichlet <- function(Y, X, n_samples = 2000, denom = "all", verbose = FALSE, ...){
  N <- ncol(Y)
  D <-  nrow(Y)
  Q <- nrow(X)

  fit_par <- ALDEx2::aldex.clr(reads = Y,conds = X, mc.samples = n_samples, denom = "all", verbose = verbose, useMC = FALSE)

  rownames.hold = row.names(ALDEx2::getMonteCarloInstances(fit_par)[[1]])
  colnames.hold = colnames(ALDEx2::getMonteCarloInstances(fit_par)[[1]])
  lambda = ALDEx2::getMonteCarloInstances(fit_par)

  for(i in 1:length(lambda)){
    lambda[[i]] = driver::clrInv_array(lambda[[i]], 1)
  }


  lambda_mat = array(as.numeric(unlist(lambda)), dim=c(D, n_samples, N))
  lambda_mat = aperm(lambda_mat, c(1,3,2))

  return(list(lambda_list = lambda, lambda_mat = lambda_mat))
}

