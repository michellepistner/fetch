#' Fetches global test statistic
#'
#' Tabulates the global test statistic according to Hoetelling's T2
#'
#' @param samples An array of CLR samples
#' @param mu_vec The mean vector to test against.
#'
#' @return A single test statistic and p-value.
#'
#' @examples
#'
#'
#' @export
global_test <- function(samples, mu_vec, conds, hyp_global){
  samples_used = samples
  n = dim(samples_used)[3]
  p = dim(samples_used)[1] * dim(samples_used)[2]

  if(hyp_global == "value"){
    X_samples = apply(samples_used, MARGIN = 3, FUN = function(mat){c(mat)})
    samp_mean = Rfast::rowmeans(X_samples)
    X_jittered = X_samples + matrix(rnorm(nrow(X_samples)*ncol(X_samples), sd = 1e-1), nrow = nrow(X_samples))
    Sigma_samp = Rfast::cova(t(X_jittered))/n
    Sigma.inv = chol2inv(chol(Sigma_samp))
    f_stat = ((n-p)/(p*(n-1))) *t(samp_mean - mu_vec) %*% Sigma.inv %*% (samp_mean - mu_vec)
    p_val = pf(f_stat, df1 = p, df2 = n-p, lower.tail = FALSE)
    return(list(f_stat = f_stat, p_val = p_val))
  } else if(hyp_global == "conds"){
    if(length(unique(c(conds))) > 2) return("The number of unique conditions is greater than 2! Currently not supported.")
    X_samples = apply(samples_used, MARGIN = c(1,2), FUN = mean)
    conds1 = unique(c(conds))[1]
    cond1_samples = X_samples[,conds == conds1]
    cond2_samples = X_samples[,conds != conds1]
    ###Calculating means
    X_mean = Rfast::rowmeans(cond1_samples)
    Y_mean = Rfast::rowmeans(cond1_samples)
    X_jittered = cond1_samples + matrix(rnorm(nrow(cond1_samples)*ncol(cond1_samples), sd = .75), nrow = nrow(cond1_samples))
    Y_jittered = cond2_samples + matrix(rnorm(nrow(cond2_samples)*ncol(cond2_samples), sd = .75), nrow = nrow(cond2_samples))

    nX = nrow(cond1_samples)
    nY = nrow(cond2_samples)
    Sigma_X = Rfast::cova(t(X_jittered))/(nX-1)
    Sigma_Y = Rfast::cova(t(Y_jittered))/(nY-1)

    Sigma_samp = ((nX-1) * Sigma_X + (nY-1) * Sigma_Y)/(nX + nY - 2)

    Sigma.inv = chol2inv(chol(Sigma_samp))
    f_stat = ((nX*nY)/(nX + nY)) *t(X_mean - Y_mean) %*% Sigma.inv %*% (X_mean - Y_mean)
    f_stat = ((nX + nY - 1 -p)/((nX + nY - 2)*p)) * f_stat
    p_val = pf(f_stat, df1 = p, df2 = n + n - 1 -p, lower.tail = FALSE)

    return(list(f_stat = f_stat, p_val = p_val))
  } else{
    return(paste("Global test ", hyp_global, " is not supported!"))
  }
}


#' T-test code from \code{ALDEx2} package
#'
#' Tabulates local t-tests for each taxa.
#'
#' @param clr A list of CLR samples
#' @param X A vector of conditions
#'
#' @return A single test statistic and p-value for each taxa.
#'
#' @examples
#'
#'
#' @export
aldex_ttest <- function(clr, X, smpl.ids, feature.names, feature.number, mc.instances,  paired.test=FALSE, hist.plot=FALSE, verbose=FALSE) {

  # Use clr conditions slot instead of input
  conditions <- c(X)
  if(length(unique(conditions)) != 2){
    stop("Please define the aldex.clr object for a vector of two unique 'conditions'.")
  }


  conditions <- as.factor( conditions )
  levels     <- levels( conditions )


  # generate the comparison sets from the condition levels
  levels <- vector( "list", length( levels ) )
  names( levels ) <- levels( conditions )
  sets <- names(levels)
  setAsBinary <- as.numeric(conditions == sets[1])
  setA <- which(conditions == sets[1])
  setB <- which(conditions == sets[2])

  # set up the t-test result containers
  wi.p.matrix <- as.data.frame(matrix(1, nrow = feature.number, ncol = mc.instances))
  wi.BH.matrix <- wi.p.matrix # duplicate result container
  we.p.matrix <- wi.p.matrix # duplicate result container
  we.BH.matrix <- wi.p.matrix # duplicate result container

  # mc.i is the i-th Monte-Carlo instance
  if(verbose) message("running tests for each MC instance:")
  mc.all <- clr
  for(mc.i in 1:mc.instances){


    # generate a matrix of i-th Monte-Carlo instance, columns are samples, rows are features
    t.input <- sapply(mc.all, function(y){y[, mc.i]})

    wi.p.matrix[, mc.i] <- wilcox.fast(t.input, setAsBinary, paired.test)
    wi.BH.matrix[, mc.i] <- p.adjust(wi.p.matrix[, mc.i], method = "BH")

    we.p.matrix[, mc.i] <- t_fast(t.input, setAsBinary, paired.test)
    we.BH.matrix[, mc.i] <- p.adjust(we.p.matrix[, mc.i], method = "BH")
  }

  if(hist.plot == TRUE){

    par(mfrow=c(2,2))
    hist(we.p.matrix[,1], breaks=99, main="Welch's P values Instance 1")
    hist(wi.p.matrix[,1], breaks=99, main="Wilcoxon P values Instance 1")
    hist(we.BH.matrix[,1], breaks=99, main="Welch's BH values Instance 1")
    hist(wi.BH.matrix[,1], breaks=99, main="Wilcoxon BH values Instance 1")
    par(mfrow=c(1,1))
  }

  # get the Expected values of p, q and lfdr
  we.ep <- rowMeans(we.p.matrix) # rowMeans is faster than apply()!!
  we.eBH <- rowMeans(we.BH.matrix)
  wi.ep <- rowMeans(wi.p.matrix)
  wi.eBH <- rowMeans(wi.BH.matrix)

  z <- data.frame(we.ep, we.eBH, wi.ep, wi.eBH)
  return(z)
}

#' Tabulates individual t-tests (fast) from \code{ALDEx2} package
#'
#' @param data An list of CLR samples
#' @param group A vector of conditions for each sample
#' @param paired Conducted paired t-test?
#'
#' @return A single test statistic and p-value for each taxa.
#'
#' @export
t_fast <- function(data, group, paired){

  grp1 <- group == unique(group)[1]
  grp2 <- group == unique(group)[2]
  n1 <- sum(grp1)
  n2 <- sum(grp2)

  if(paired){

    # Order pairs for the mt.teststat function
    if(n1 != n2) stop("Cannot pair uneven groups.")
    i.1 <- which(grp1)
    i.2 <- which(grp2)
    paired.order <- unlist(lapply(1:length(i.1), function(i) c(i.1[i], i.2[i])))

    t <- multtest::mt.teststat(data[, paired.order], as.numeric(grp1)[paired.order],
                               test = "pairt", nonpara = "n")
    df <- length(i.1) - 1
    return(pt(abs(t), df = df, lower.tail = FALSE) * 2)

  }else{

    t <- multtest::mt.teststat(data, as.numeric(grp1), test = "t", nonpara = "n")
    s1 <- apply(data[, grp1], 1, sd)
    s2 <- apply(data[, grp2], 1, sd)
    df <- ( (s1^2/n1 + s2^2/n2)^2 )/( (s1^2/n1)^2/(n1-1) + (s2^2/n2)^2/(n2-1) )
    return(pt(abs(t), df = df, lower.tail = FALSE) * 2)
  }
}

#' Tabulates individual Wilcox t-tests (fast) from \code{ALDEx2} package
#'
#' @param data An list of CLR samples
#' @param group A vector of conditions for each sample
#' @param paired Conducted paired t-test?
#'
#' @return A single test statistic and p-value for each taxa.
#'
#' @export
wilcox.fast <- function(data, group, paired){

  if(ncol(data) != length(group)) stop("Use rows for feature data.")
  grp1 <- group == unique(group)[1]
  grp2 <- group == unique(group)[2]
  n1 <- sum(grp1)
  n2 <- sum(grp2)

  # Check for ties in i-th Monte-Carlo instance
  data.t <- t(data)
  if(paired){
    anyTies <- any(apply(data.t[grp1, ] - data.t[grp2, ], 2,
                         function(x) length(unique(x))) != ncol(data) / 2)
  }else{
    anyTies <- any(apply(data.t, 2,
                         function(x) length(unique(x))) != ncol(data))
  }

  # Ties trigger slower, safer wilcox.test function
  if(anyTies){
    return(apply(data.t, 2, function(i){
      wilcox.test(x = i[grp1], y = i[grp2], paired = paired, correct = FALSE)$p.value}))
  }

  if(paired){

    if(n1 != n2) stop("Cannot pair uneven groups.")
    data.diff <- data.t[grp1, ] - data.t[grp2, ]
    V <- apply(data.diff, 2, function(x) sum(rank(abs(x))[x > 0]))
    topscore <- (n1 * (n1+1)) / 2
    V.lower <- ifelse(V > topscore / 2, topscore - V, V)
    if(sum(grp1) < 50){ # as per wilcox test, use exact -- ASSUMES NO TIES!!
      V.p <- psignrank(V.lower, n1) * 2
      return(ifelse(V.p > 1, 1, V.p)) # psignrank returns non-zero for W = mean
    }else{ # Use normal approximation
      V.std <- (topscore/2 - V.lower) / sqrt(n1*(n1 + 1) * (2*n1 + 1) / 24) # wilcox.test uses denom = 24
      return(pnorm(V.std, lower.tail = FALSE) * 2)
    }


  }else{

    W.std <- multtest::mt.teststat(data, as.numeric(grp1), test = "wilcoxon")
    if(sum(grp1) < 50 && sum(grp2) < 50){ # as per wilcox test, use exact -- ASSUMES NO TIES!!
      W.var <- sqrt((n1*n2) * (n1+n2+1) / 12)
      W <- abs(W.std) * W.var + (n1*n2) / 2
      W.p <- pwilcox(W - 1, n1, n2, lower.tail = FALSE) * 2
      return(ifelse(W.p > 1, 1, W.p)) # pwilcox returns non-zero for W = mean
    }else{ # Use normal approximation
      return(pnorm(abs(W.std), lower.tail = FALSE) * 2)
    }
  }
}


#' Kruskal-Wallis code from \code{ALDEx2} package
#'
#' Tabulates local Kruskal-Wallis tests for each taxa.
#'
#' @param clr An list of CLR samples
#' @param X A vector of conditions
#'
#' @return A single test statistic and p-value for each taxa.
#'
#' @examples
#'
#'
#' @export
aldex_kw <- function(clr, X, smpl.ids, feature.names, feature.number, mc.instances, useMC=FALSE, verbose=FALSE){

  # Use clr conditions slot instead of input
  conditions <- X

  # make sure that the multicore package is in scope and return if available
  is.multicore = FALSE

  if ("BiocParallel" %in% rownames(installed.packages()) & useMC){
    message("multicore environment is OK -- using the BiocParallel package")
    #require(BiocParallel)
    is.multicore = TRUE
  }
  else {
    message("operating in serial mode")
  }


  conditions <- as.factor( conditions )
  levels     <- levels( conditions )


  # generate the comparison sets from the condition levels
  levels <- vector( "list", length( levels ) )
  names( levels ) <- levels( conditions )
  sets <- names(levels)

  # set up the glm results containers
  glm.matrix.p <- as.data.frame(matrix(1, nrow = feature.number, ncol = mc.instances))
  glm.matrix.pBH <- glm.matrix.p # duplicate result container
  kw.p.matrix <- glm.matrix.p # duplicate result container
  kw.pBH.matrix <- glm.matrix.p # duplicate result container

  # mc.i is the i-th Monte-Carlo instance
  if(verbose) message("running tests for each MC instance:")
  mc.all <- clr
  for(mc.i in 1:mc.instances){


    # generate a matrix of i-th Monte-Carlo instance, columns are samples, rows are features
    t.input <- sapply(mc.all, function(y){y[, mc.i]})

    # do glms on each feature and make a list of glm outputs
    x <-
      apply(t.input, 1, function(yy) {
        glm(as.numeric(yy) ~ factor(conditions))
      })

    # calculate p-values for generalized linear model
    if(is.multicore == TRUE){
      pps <- BiocParallel::bplapply(x, drop1, test = "Chis")
    }else{
      pps <- lapply(x, drop1, test = "Chis")
    }
    glm.matrix.p[, mc.i] <- sapply(pps, function(x){x[[5]][2]})
    glm.matrix.pBH[, mc.i] <- as.numeric(p.adjust(glm.matrix.p[, mc.i], method = "BH"))

    # calculate p-values for Kruskal Wallis test
    kw.p.matrix[, mc.i] <-
      apply(t.input, 1, function(yy){
        kruskal.test(yy, g = factor(conditions))[[3]]
      })
    kw.pBH.matrix[, mc.i] <- as.numeric(p.adjust(kw.p.matrix[, mc.i], method = "BH"))

  }

  # get the Expected values of p, q and lfdr
  glm.ep <- rowMeans(glm.matrix.p) # rowMeans is faster than apply()!!
  glm.eBH <- rowMeans(glm.matrix.pBH)
  kw.ep <- rowMeans(kw.p.matrix)
  kw.eBH <- rowMeans(kw.pBH.matrix)

  z <- data.frame(kw.ep, kw.eBH, glm.ep, glm.eBH)
  rownames(z) <- feature.names
  return(z)
}


aldex_effect <- function(clr, X, verbose=TRUE, include.sample.summary=FALSE, useMC=FALSE, CI=FALSE, glm.conds=NULL){

  # Use clr conditions slot instead of input
  conditions = X

  is.multicore = FALSE

  if ("BiocParallel" %in% rownames(installed.packages()) & useMC==TRUE){
    message("multicore environment is OK -- using the BiocParallel package")
    #require(BiocParallel)
    is.multicore = TRUE
  }
  else {
    if (verbose == TRUE) message("operating in serial mode")
  }

  nr <- feature.number # number of features
  rn <- feature.names # feature names
  # ---------------------------------------------------------------------

  # sanity check to ensure only two conditons passed to this function
  conditions <- as.factor( conditions )
  levels     <- levels( conditions )


  levels <- vector( "list", length( levels ) )
  names( levels ) <- levels( conditions )

  for ( l in levels( conditions ) ) {
    levels[[l]] <- which( conditions == l )
    if ( length( levels[[l]] ) < 2 ) stop("condition level '",l,"' has less than two replicates")
  }

  # end sanity check
  if (verbose == TRUE) message("sanity check complete")

  # Summarize the relative abundance (rab) win and all groups

  rab <- vector( "list", 3 )
  names(rab) <- c( "all", "win", "spl" )
  rab$win <- list()

  #this is the median value across all monte carlo replicates
  cl2p <- NULL
  for ( m in clr ) cl2p <- cbind( cl2p, m )
  rab$all <- t(apply( cl2p, 1, median ))
  rm(cl2p)
  gc()
  if (verbose == TRUE) message("rab.all  complete")

  #this is the median value across all monte carlo replicates per level
  for ( level in levels(conditions) ) {
    cl2p <- NULL
    for ( i in levels[[level]] ) cl2p <- cbind( cl2p, clr[[i]] )
    rab$win[[level]] <- t(apply( cl2p, 1, median ))
    rm(cl2p)
    gc()
  }
  if (verbose == TRUE) message("rab.win  complete")

  if (is.multicore == TRUE)  rab$spl <- BiocParallel::bplapply( getMonteCarloInstances(clr), function(m) { t(apply( m, 1, median )) } )
  if (is.multicore == FALSE) rab$spl <- lapply( getMonteCarloInstances(clr), function(m) { t(apply( m, 1, median )) } )

  if (verbose == TRUE) message("rab of samples complete")

  # ---------------------------------------------------------------------
  # Compute diffs btw and win groups

  l2d <- vector( "list", 2 )
  names( l2d ) <- c( "btw", "win" )
  l2d$win <- list()

  # abs( win-conditions diff ), btw smps
  #this generates a linear sample of the values rather than an exhaustive sample
  for ( level in levels(conditions) ) {
    concat <- NULL
    for ( l1 in sort( levels[[level]] ) ) {
      concat <- cbind(  getMonteCarloReplicate(clr,l1),concat )

    }

    #if the sample is huge, only sample 10000
    if ( ncol(concat) < 10000 ){
      sampl1 <- t(apply(concat, 1, function(x){sample(x, ncol(concat))}))
      sampl2 <- t(apply(concat, 1, function(x){sample(x, ncol(concat))}))
    } else {
      sampl1 <- t(apply(concat, 1, function(x){sample(x, 10000)}))
      sampl2 <- t(apply(concat, 1, function(x){sample(x, 10000)}))
    }
    l2d$win[[level]] <- cbind( l2d$win[[level]] , abs( sampl1 - sampl2 ) )
    rm(sampl1)
    rm(sampl2)
    gc()
  }
  if (verbose == TRUE) message("within sample difference calculated")
  # Handle the case when the groups have different spl sizes
  # get the minimum number of win spl comparisons
  ncol.wanted <- min( sapply( l2d$win, ncol ) )
  # apply multicore paradigm ML
  if (is.multicore == TRUE) l2d$win  <- BiocParallel::bplapply( l2d$win, function(arg) { arg[,1:ncol.wanted] } )
  if (is.multicore == FALSE) l2d$win  <- lapply( l2d$win, function(arg) { arg[,1:ncol.wanted] } )

  # btw condition diff (signed)
  #get the btw condition as a random sample rather than exhaustive search
  concatl1 <- NULL
  concatl2 <- NULL
  for( l1 in levels[[1]] ) concatl1 <- cbind( getMonteCarloReplicate(clr,l1),concatl1 )
  for( l2 in levels[[2]] ) concatl2 <- cbind( getMonteCarloReplicate(clr,l2),concatl2 )

  sample.size <- min(ncol(concatl1), ncol(concatl2))

  if ( sample.size < 10000 ){
    smpl1 <- t(apply(concatl1, 1, function(x){sample(x, sample.size)}))
    smpl2 <- t(apply(concatl2, 1, function(x){sample(x, sample.size)}))
  } else {
    smpl1 <- t(apply(concatl1, 1, function(x){sample(x, 10000)}))
    smpl2 <- t(apply(concatl2, 1, function(x){sample(x, 10000)}))
  }
  l2d$btw <- smpl2 - smpl1

  rm(smpl1)
  rm(smpl2)
  gc()
  if (verbose == TRUE) message("between group difference calculated")

  win.max <- matrix( 0 , nrow=nr , ncol=ncol.wanted )
  l2d$effect <- matrix( 0 , nrow=nr , ncol=ncol(l2d$btw) )
  rownames(l2d$effect) <- rn

  ###the number of elements in l2d$btw and l2d$win may leave a remainder when
  #recycling these random vectors. Warnings are suppressed because this is not an issue
  #for this calculation. In fact, any attempt to get rid of this error would
  #decrease our power as one or both vectors would need to be truncated gg 20/06/2013

  options(warn=-1)

  for ( i in 1:nr ) {
    win.max[i,] <- apply( ( rbind( l2d$win[[1]][i,] , l2d$win[[2]][i,] ) ) , 2 , max )
    l2d$effect[i,] <- l2d$btw[i,] / win.max[i,]
  }

  options(warn=0)

  rownames(win.max)   <- rn
  attr(l2d$win,"max") <- win.max
  rm(win.max)

  # ---------------------------------------------------------------------
  # Summarize diffs

  l2s <- vector( "list", 2 )
  names( l2s ) <- c( "btw", "win" )
  l2s$win <- list()

  l2s$btw <- t(apply( l2d$btw, 1, median ))
  l2s$win  <- t(apply( attr(l2d$win,"max"), 1, median ))
  if (verbose == TRUE) message("group summaries calculated")

  if(CI == FALSE) {
    effect  <- t(apply( l2d$effect, 1, median ))
  } else {
    effectlow <- t(apply( l2d$effect, 1, function(x) quantile(x, probs=0.025, names=FALSE) ))
    effecthigh <- t(apply( l2d$effect, 1, function(x) quantile(x, probs=0.975, names=FALSE) ))
    effect  <- t(apply( l2d$effect, 1, median ))
  }
  overlap <- apply( l2d$effect, 1, function(row) { min( aitchison.mean( c( sum( row < 0 ) , sum( row > 0 ) ) + 0.5 ) ) } )
  if (verbose == TRUE) message("effect size calculated")

  # make and fill in the data table
  # i know this is inefficient, but it works and is not a bottleneck
  if(CI == FALSE) {
    rv <- list(
      rab = rab,
      diff = l2s,
      effect = effect,
      overlap = overlap
    )
  } else {
    rv <- list(
      rab = rab,
      diff = l2s,
      effect = effect,
      effectlow = effectlow,
      effecthigh = effecthigh,
      overlap = overlap
    )
  }

  if (verbose == TRUE) message("summarizing output")

  y.rv <- data.frame(t(rv$rab$all))
  colnames(y.rv) <- c("rab.all")
  for(i in names(rv$rab$win)){
    nm <- paste("rab.win", i, sep=".")
    y.rv[,nm] <- data.frame(t(rv$rab$win[[i]]))
  }
  if (include.sample.summary == TRUE){
    for(i in names(rv$rab$spl)){
      nm <- paste("rab.sample", i, sep=".")
      y.rv[,nm] <- data.frame(t(rv$rab$spl[[i]]))
    }

  }
  for(i in names(rv$diff)){
    nm <- paste("diff", i, sep=".")
    y.rv[,nm] <- data.frame(t(rv$diff[[i]]))
  }
  if(CI == FALSE) {
    y.rv[,"effect"] <- data.frame(t(rv$effect))
    y.rv[,"overlap"] <- data.frame(rv$overlap)
  } else {
    y.rv[,"effect"] <- data.frame(t(rv$effect))
    y.rv[,"effect.low"] <- data.frame(t(rv$effectlow))
    y.rv[,"effect.high"] <- data.frame(t(rv$effecthigh))
    y.rv[,"overlap"] <- data.frame(rv$overlap)
  }
  return(y.rv)

}

#' Helper function to calculate the Aitchinson mean from \code{ALDEx2} package
#'
#'
#' @param n A vector of non-negative integer counts
#'
#' @return Probability vector of expected frequencies
#'
#' @examples
#'
#'
#' @export
aitchison.mean <- function( n, log=FALSE ) {

  # Input is a vector of non-negative integer counts.
  # Output is a probability vector of expected frequencies.
  # If log-frequencies are requested, the uninformative subspace is removed.

  n <- round( as.vector( n, mode="numeric" ) )
  if ( any( n < 0 ) ) stop("counts cannot be negative")

  a <- n + 0.5
  sa <- sum(a)

  log.p <- digamma(a) - digamma(sa)
  log.p <- log.p - mean(log.p)

  if ( log ) return(log.p)

  p <- exp( log.p - max(log.p) )
  p <- p / sum(p)
  return(p)
}

#' GLM code from \code{ALDEx2} package
#'
#' Tabulates local tests for each taxa using a generalized linear model.
#'
#' @param clr An list of CLR samples
#' @param X A matrix of conditions
#'
#' @return A single test statistic and p-value for each taxa.
#'
#' @examples
#'
#'
#' @export
aldex_glm <- function (mc, clr, X, verbose = FALSE, ...)
{
  conditions <- t(X)
  lr2glm <- function(lr, conditions, ...) {
    model. <- conditions
    glms <- apply(lr, 2, function(x) {
      glm(x ~ model., ...)
    })
    extract <- function(model) {
      x <- coef(summary(model))
      coefs <- lapply(1:nrow(x), function(i) {
        y <- x[i, , drop = FALSE]
        colnames(y) <- paste(rownames(y), colnames(y))
        y
      })
      do.call("cbind", coefs)
    }
    extracts <- lapply(glms, extract)
    df <- do.call("rbind", extracts)
    rownames(df) <- colnames(lr)
    df <- as.data.frame(df)
    pvals <- colnames(df)[grepl("Pr\\(>", colnames(df))]
    df.bh <- df[, pvals]
    colnames(df.bh) <- paste0(colnames(df.bh), ".BH")
    for (j in 1:ncol(df.bh)) {
      df.bh[, j] <- p.adjust(df.bh[, j])
    }
    cbind(df, df.bh)
  }
  if (verbose)
    message("running tests for each MC instance:")
  k <- ALDEx2::numMCInstances(clr)
  r <- 0
  for (i in 1:k) {
    mci_lr <- t(sapply(mc, function(x) x[, i]))
    r <- r + lr2glm(mci_lr, conditions)
  }
  r/k
}

