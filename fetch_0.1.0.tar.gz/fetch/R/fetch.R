
#' Fetches test statistics for differential abundance
#'
#' Master function for completing global and local tests for differential abundance.
#'
#'
#' @param Y An OTU or counts table
#' @param X A matrix of covariates
#' @param denom  Denominator of CLR transform. Follows same convention as \code{aldex2} function.
#' @param test A character string (\code{"global"}, \code{"t"}, \code{"kw"}, or \code{"glm"}). Global test is based on the F-distribution. Local tests are fit using \code{ALDEx2} package.
#' @param mu_vec A numeric mean vector for the global test. Default is zero.
#' @param scale_sim A boolean to toggle scale simulation. Current default is \code{FALSE}. Scale simulation is not currently supported but in development.
#' @param total_model Total model for scale simulation. Default is \code{"unif"}.
#' @param alpha Size of uniform ball for \code{"unif"} total model if scale simulation is used.
#' @param sample.totals A vector of total abundance information for each sample (if desired for total model).
#' @param sample A vector with sample labels if total model is used.
#' @param hyp_global A string vector, either "conds" or "value". Is the hypothesis test by condition or by a given mean vector?
#'
#' @return Test statistics and corresponding p-values
#'
#' @examples
#'   set.seed(1)
#'   Y = rmultinom(10, 10000, prob = seq(1:15))
#'   X = matrix(sample(1:2,10,replace=TRUE),ncol = 10)
#'   out = fetch(Y, X, denom = "iqlr", test = "global")
#'   out
#'
#' @export
fetch <- function(Y, X, n_samples = 2000, denom = "all", test = "global", mu_vec = NULL,  scale_sim = FALSE, total_model = "unif", alpha = 1, sample.totals = NULL, sample = NULL, hyp_global = "value",...){

  N <- ncol(Y)
  D <-  nrow(Y)
  Q <- nrow(X)
  if(N*D >= n_samples)
    stop("You must specify more samples based on the dimension of Y (e.g. n_samples > nrow(Y)*ncol(Y).")
  if (any(c(N, D, Q) <= 0))
    stop("N, D, and Q must all be greater than 0 (D must be greater than 1)")
  if (D <= 1)
    stop("D must be greater than 1")
  if(ncol(X) != ncol(Y))
    stop("Mismatch between dimension of X and Y")
  if(is.matrix(X) & nrow(X)>1 & denom != "all")
    stop(paste0("Denom ", denom, " is only supported for a single condition!"))

  fit_multDir = multDirichlet(Y, X, n_samples, denom)

  if(isTRUE(scale_sim)){
    if(total_model == "unif"){
      if(is.null(sample.totals)){
        tau <- scale_unif(N=N, alpha=alpha)
      } else{
        tau <- scale_unif(sample=1:length(sample.totals), alpha=alpha, w = sample.totals)
      }
    }
    ##Transform samples back
    lambda.par = fit_multDir$lambda_mat
    ##Multiply by the totals
    lambda = array(NA, dim = dim(lambda.par))

    for(i in 1:n_samples){
      lambda[,,i] =sweep(lambda.par[,,i], MARGIN=2, tau$tau[,i]/tau$tau[1,i], `*`)
    }
  } else{
    lambda = fit_multDir$lambda_mat

    for(i in 1:dim(lambda)[3]){
      if(denom == "all"){
        lambda[,,i] = driver::clr_array(lambda[,,i], 1)
      } else if (denom == "iqlr"){
        lambda[,,i] = iqlr(lambda[,,i], parts = 1)
      } else{
        stop(paste0("denom: ", denom, " not supported!"))
      }
    }
  }

  if(test == "global"){
    if(is.null(mu_vec)){
      mu_vec = rep(0, dim(fit_multDir$lambda_mat)[1]*dim(fit_multDir$lambda_mat)[2])
    }
    tmp_test = global_test(lambda, mu_vec, X, hyp_global)
    return(tmp_test)
  } else if(test == "t"){
    fitc = list()
    for(i in 1:length(fit_multDir$lambda_list)){
      fitc[[i]] = driver::clr_array(fit_multDir$lambda_list[[i]], 1)
    }
    # get dimensions, names, etc from the input data
    smpl.ids <- rownames(fit_multDir$lambda_mat[,,1])
    feature.names <- names(fit_multDir$lambda_mat[,,1])
    feature.number <- dim(fit_multDir$lambda_mat)[1]
    mc.instances <- dim(fit_multDir$lambda_mat)[3]

    x.tt <- aldex_ttest(fitc, c(X), smpl.ids, feature.names, feature.number, mc.instances, paired.test = FALSE, hist.plot = FALSE,
                        verbose = FALSE)
    ##x.effect <- aldex_effect(fitc, c(X),smpl.ids, feature.names, feature.number, mc.instances, include.sample.summary=FALSE, verbose=FALSE)
    z <- data.frame(x.tt, check.names=F)
    return(z)
  } else if(test == "kw"){
    fitc = list()
    for(i in 1:length(fit_multDir$lambda_list)){
      fitc[[i]] = driver::clr_array(fit_multDir$lambda_list[[i]], 1)
    }
    smpl.ids <- rownames(fit_multDir$lambda_mat[,,1])
    feature.names <- names(fit_multDir$lambda_mat[,,1])
    feature.number <- dim(fit_multDir$lambda_mat)[1]
    mc.instances <- dim(fit_multDir$lambda_mat)[3]
    x.tt <- aldex_kw(fitc, c(X), smpl.ids, feature.names, feature.number, mc.instances)
    ##x.effect <- aldex_effect(fitc, c(X), include.sample.summary=FALSE, verbose=FALSE)
    z <- data.frame( x.tt, check.names=F)
    return(z)

  } else if(test == "lm"){
    fitc = list()
    for(i in 1:length(fit_multDir$lambda_list)){
      fitc[[i]] = driver::clr_array(fit_multDir$lambda_list[[i]], 1)
    }
    fit_tmp = ALDEx2::aldex.clr(reads = Y,conds = X, mc.samples = n_samples, denom = "all", verbose = verbose, useMC = FALSE)
    x.tt <- aldex_glm(fitc, fit_tmp, X)
    ##x.effect <- aldex_effect(fitc,X, include.sample.summary=FALSE, verbose=FALSE)
    z <- data.frame(x.tt, check.names=F)
    return(z)

  }
}#End of function
