#' A total model based on the uniform ball
#'
#' Samples from a uniform ball of correct dimension.
#'
#' @param w (If desired) Totals for each sample to center the ball.
#' @param sample The labels for each of the samples. Needed if \code{w} is supplied.
#' @param N Dimension of the uniform ball
#' @param alpha Size of the uniform ball
#' @param n_samples Number of samples to be drawn
#' @param log_scale Should the log-scale be used?
#'
#' @return Transformed samples from the uniform ball.
#'
#'
#' @export
scale_unif = function (w = NULL, sample = NULL, N = NULL, alpha = NULL, n_samples = 2000,
                    log_scale = FALSE, use_names = TRUE)
{
  K <- length(w)
  if (!is.null(w) & is.null(sample))
    stop("sample must be non-null if w is passed")
  if (!is.null(w) & !is.null(sample)) {
    if (log_scale) {
      w <- log(w)
    }
    if (!is.factor(sample))
      sample <- as.factor(sample)
    if (!is.null(N))
      stopifnot(N == length(levels(sample)))
    if (length(sample) != length(w))
      stop("sample and w have different lengths")
    N <- length(levels(sample))
    m <- split(w, sample)
    m <- unlist(lapply(m, mean))
    m <- m[levels(sample)]
    if (log_scale) {
      w <- exp(w)
      m <- exp(m)
    }
  }
  else {
    stopifnot(!is.null(N))
    m <- NULL
  }
  tau <- driver::rUnifSphere(n_samples, N - 1, alpha, shell_only = FALSE)
  if (!is.null(w)) {
    m <- ilr(m)
    tau <- sweep(tau, 1, m, FUN = `+`)
  }
  tau <- t(driver::ilrInv(t(tau)))
  out <- list(N = as.integer(N), K = as.integer(K), iter = as.integer(n_samples),
                   w = w, sample = sample, alpha = alpha, tau = tau,
                   log_scale = log_scale)
  return(out)
}

