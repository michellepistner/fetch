#' Calculates the IQLR of a matrix of counts.
#'
#' @param Y An matrix of counts.
#' @param parts The dimension that represents the compositional variables (parts).
#'
#' @return A matrix of the IQLR transformed counts.
#'
#'
#' @export
iqlr <- function(Y, parts = 1){
  ##Find the indicies
  index = iqlr_features(Y,parts = 1)
  coord = (parts %%2) + 1
  gm_trunc = log2(apply(Y,MARGIN = coord, FUN = function(vec, index){gm_mean(vec[index])}, index=index))
  iqlr.calc = log2(Y)
  iqlr.calc = sweep(iqlr.calc, MARGIN = coord, STATS = gm_trunc, FUN = "-")
  return(iqlr.calc)
}##end of function

#' Finds taxa that should be used in the denominator in the IQLR
#'
#'
#' @param Y An matrix of counts.
#' @param parts The dimension that represents the compositional variables (parts).
#'
#' @return A vector of indices to be used in the denominator.
#'
#'
#' @export
iqlr_features <- function(Y, parts = 1){
  ###For the matrix, compute the CLR
  clr.Y = driver::clr_array(Y, parts = parts)
  var.clr = apply(clr.Y, MARGIN = 1, FUN = var)
  quants.clr = quantile(var.clr, c(0.025,.975))
  in_range = (var.clr >= quants.clr[1]) & (var.clr <= quants.clr[2])

  tax = 1:dim(Y)[parts]
  indices = tax[in_range]
  if(length(indices) < 1)
    stop("There are no valid features for the iqlr!!")
  return(indices)
}

##Geometric mean function
gm_mean = function(x, na.rm=TRUE){
  exp(sum(log(x[x > 0]), na.rm=na.rm) / length(x))
}
